sap.ui.define(
    ["sap/ui/core/Control","sap/m/Button"],
    function (Control,Button) {
      return Control.extend("com.pai.ocn.painter.control.Header", {
        metadata: {
          properties: {
            type: { type: "string" }
          },
          aggregations: {
            _newDodle: { type: "sap.m.Button", multiple: false },
            _sendDodle: { type: "sap.m.Button", multiple: false }
          },
          events: {
            newDoddle: {}
          }
        },
        init: function () {


          this.setAggregation("_newDodle", new Button({
            icon: "sap-icon://refresh",
            press: function () {
              this.fireNewDoddle();
            }.bind(this)
          }).addStyleClass("myrefreshbutton"));

          this.setAggregation("_sendDodle", new Button({
            icon: "sap-icon://paper-plane",
            press: function () {
              this.fireNewDoddle();
            }.bind(this)
          }).addStyleClass("mysendbutton"));


        },
        renderer: {
          apiVersion: 2,
          render: function (oRm, oControl) {
  
  
            oRm.openStart("div");
            oRm.class("top-nav");
            oRm.openEnd();
            

                
                //for the doodle name
                oRm.openStart("div");
                oRm.class("doddle");
                
                oRm.openEnd();
                
                  oRm.openStart("p");
                  oRm.class("leftp");
                  oRm.attr("id", "doddle");
                  oRm.openEnd();
                  oRm.text(oControl.getType());
                  oRm.close("p");

                oRm.close("div");
                //end of the doodle name

                //for the buttons
                oRm.openStart("div");
                oRm.class("section");
                oRm.attr("id", "buttons");
                oRm.openEnd();

                  oRm.openStart("span");
                  oRm.class("leftp");
                  oRm.attr("id", "timer")
                  oRm.openEnd();
                  oRm.text("00:00");
                  oRm.close("span");


                oRm.close("div");
                //end of the buttons


                //for the timer
                oRm.openStart("div");
                oRm.class("sectionright");
                oRm.attr("id", "timer");
                oRm.openEnd();

                    oRm.openStart("p");
                    oRm.class("rightp");
                    oRm.openEnd();
                    oRm.renderControl(oControl.getAggregation("_newDodle"));
                    oRm.close("p");

                    oRm.openStart("p");
                    oRm.class("rightp");
                    oRm.openEnd();
                    oRm.renderControl(oControl.getAggregation("_sendDodle"));
                    oRm.close("p");

                oRm.close("div");
                //end of the timer

                                


            oRm.close("div");
   
          }
        },
        setType: function(sText){
            this.setProperty("type", sText, true);
            $("#doddle").html(sText);
           
        }
      });
    }
  );
  