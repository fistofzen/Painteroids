sap.ui.define(
  ["sap/ui/core/Control"],
  function (Control) {

    var socket, canvas, ctx, rect,
    brush = {
        x: 0,
        y: 0,
        color: '#000000',
        size: 10,
        down: false,
    },
    strokes = [],
    currentStroke = null;


    return Control.extend("com.pai.ocn.painter.control.Canvas", {
      metadata: {
        properties: {
          type: { type: "string" }
        }
      },

      renderer: {
        apiVersion: 2,
        render: function (oRm, oControl) {


  
          oRm.openStart("canvas", oControl);
          oRm.attr("id","paint");
          oRm.class("canvas");
          oRm.openEnd();
          oRm.close("canvas");
          
        }
      },
      onAfterRendering : function(arguments) {
        canvas = $('#__canvas0');
      
      canvas.attr({
        width: window.innerWidth,
        height: window.innerHeight,
    });
    ctx = canvas[0].getContext('2d');
     
    },

    ontouchstart: function(e) {
     
    },
    ontouchmove:  function(e) {
      if (brush.down){
   
        brush.x = e.pageX - rect.left;
        brush.y = e.pageY - rect.top;
  
          currentStroke.points.push({
              x: brush.x,
              y: brush.y,
          });
          console.log("x:" +e.pageX + " y:" + e.pageY)
          this.paint();
      }
    },
    ontouchend: function(e) {
     
    },
    ontouchcancel: function(e) {
       
    },
    onsapselect:  function(e) {
       
    },
    onmouseup:  function(e) {
      brush.down = false;

      brush.x = e.pageX - rect.left;
      brush.y = e.pageY - rect.top;

        currentStroke.points.push({
            x: brush.x,
            y: brush.y,
        });
        console.log("x:" +e.pageX + " y:" + e.pageY)
        this.paint();


      currentStroke = null;
    },
    onmouseover: function(e){

      
    },
    onmousedown:  function(e) {
      rect = canvas[0].getBoundingClientRect();
      brush.down = true;
      currentStroke = {
        color: brush.color,
        size: brush.size,
        points: [],
      };

      strokes.push(currentStroke);


      brush.x = e.pageX - rect.left;
      brush.y = e.pageY - rect.top;

        currentStroke.points.push({
            x: brush.x,
            y: brush.y,
        });
        console.log("x:" +e.pageX + " y:" + e.pageY)
        this.paint();

    },

    paint :  function() {
     
      ctx.clearRect(0, 0, canvas.width(), canvas.height());
      ctx.lineCap = 'round';
      for (var i = 0; i < strokes.length; i++) {
          var s = strokes[i];
          ctx.strokeStyle = s.color;
          ctx.lineWidth = s.size;
          ctx.beginPath();
          ctx.moveTo(s.points[0].x, s.points[0].y);
          for (var j = 0; j < s.points.length; j++) {
              var p = s.points[j];
              ctx.lineTo(p.x, p.y);
          }
          ctx.stroke();
      }
  }
  

    });
  }
);
