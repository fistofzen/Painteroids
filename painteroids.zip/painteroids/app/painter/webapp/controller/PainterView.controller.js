sap.ui.define([
  "com/pai/ocn/painter/controller/BaseController",
  "../model/models",
  "sap/ui/model/json/JSONModel",
], function (Controller, models, JSONModel) {
  "use strict";

  var interval;
  return Controller.extend("com.pai.ocn.painter.controller.PainterView", {

    onInit: function () {
      this.setModel(models.createMainModel());
           
    },
 
    onAfterRendering: function() {
      //init();
    },
    onHideSplash: function () {
      let that = this;
      let random = Math.floor(Math.random() * 11);
      $("#splashScreen").slideUp();
      const oBundle = this.getView().getModel("i18n").getResourceBundle();
      
      $.get("/paint/Categories?$filter=Language eq 'TR'&$top=1&$skip=" + random)
        .done(function (oResult) {
          oResult.value[0].Name = oBundle.getText("requestedDoddle") + ": "+ oResult.value[0].Name; 
          this.getModel().setSizeLimit(oResult.length);
          this.getModel().setData(oResult.value[0]);
          that.startTimer(oResult.value[0]);
        }.bind(this))
        .fail(function () {
          MessageBox.error(oBundle.getText("datarequestfailed"), {
            onClose: function (action) {
              if (action !== MessageBox.Action.CLOSE) {
                this.updateMarkerBinding();
              }
            }.bind(this)
          });
        });

    },

    onNewDoddle: function () {
      alert("9");
      let that = this;
      let random = Math.floor(Math.random() * 11);
      $("#splashScreen").slideUp();
      const oBundle = this.getView().getModel("i18n").getResourceBundle();
      
      $.get("/paint/Categories?$filter=Language eq 'TR'&$top=1&$skip=" + random)
        .done(function (oResult) {
          oResult.value[0].Name = oBundle.getText("requestedDoddle") + ": "+ oResult.value[0].Name; 
          this.getModel().setSizeLimit(oResult.length);
          this.getModel().setData(oResult.value[0]);
          
          if(interval > 0) 
            clearInterval(interval);
          
            that.startTimer(oResult.value[0]);
        }.bind(this))
        .fail(function () {
          MessageBox.error(oBundle.getText("datarequestfailed"), {
            onClose: function (action) {
              if (action !== MessageBox.Action.CLOSE) {
                //do nothing now
              }
            }.bind(this)
          });
        });

    },

    startTimer:function(oResult) {
      let display = $("#timer");
      var timer = oResult.Duration, minutes, seconds;
      interval = setInterval(function () {
          minutes = parseInt(timer / 60, 10);
          seconds = parseInt(timer % 60, 10);
  
          minutes = minutes < 10 ? "0" + minutes : minutes;
          seconds = seconds < 10 ? "0" + seconds : seconds;
  
          $("#buttons span")[0].textContent = minutes + ":" + seconds;
  
          if (--timer < 0) {
              timer = oResult.Duration;
          }
      }, 1000);

    }

  });
});
